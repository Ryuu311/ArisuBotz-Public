
script ini free, script ini adalah script nanobotz saya hanya mengrename saja sampai akar, dan menambahkan fitur. saya tidak bermaksud mengambil script buatan bang danz, saya hanya mengrename saja.

dan terima kasih atas bang danznano atas script free nya ini
saya izin rename untuk mengupdate scnya 
© NanoBotz



UPDATE BY DINZID OFC


CARA MENGGANTI THUMB IMAGE

1 PERGI KE DinzID.js

2 CARI : case 'menu'

3 SCROL KEBAWAH SAMPAI KETEMU ThumbnailUrl : 

4 TEMPEL THUMB URL KALIAN 

SELESAIII